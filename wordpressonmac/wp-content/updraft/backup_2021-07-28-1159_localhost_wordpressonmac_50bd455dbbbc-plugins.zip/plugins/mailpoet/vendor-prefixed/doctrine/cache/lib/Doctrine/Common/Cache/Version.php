<?php
 namespace MailPoetVendor\Doctrine\Common\Cache; if (!defined('ABSPATH')) exit; class Version { public const VERSION = '1.9.0-DEV'; } 