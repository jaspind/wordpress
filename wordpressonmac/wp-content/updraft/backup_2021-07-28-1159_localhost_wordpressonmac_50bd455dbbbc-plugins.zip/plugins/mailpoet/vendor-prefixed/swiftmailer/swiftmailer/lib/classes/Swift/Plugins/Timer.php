<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Plugins_Timer { public function getTimestamp(); } 