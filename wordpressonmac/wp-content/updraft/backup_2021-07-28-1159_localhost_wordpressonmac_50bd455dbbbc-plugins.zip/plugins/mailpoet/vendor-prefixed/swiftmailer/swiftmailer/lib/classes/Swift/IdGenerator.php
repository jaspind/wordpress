<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_IdGenerator { public function generateId(); } 