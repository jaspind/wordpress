<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Mime_HeaderEncoder extends \MailPoetVendor\Swift_Encoder { public function getName(); } 