<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Events_EventListener { } 