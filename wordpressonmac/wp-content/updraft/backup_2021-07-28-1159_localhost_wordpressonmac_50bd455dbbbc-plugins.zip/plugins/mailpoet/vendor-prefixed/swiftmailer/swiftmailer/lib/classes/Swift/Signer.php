<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Signer { public function reset(); } 