<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Plugins_Pop_Pop3Connection { public function connect(); public function disconnect(); } 