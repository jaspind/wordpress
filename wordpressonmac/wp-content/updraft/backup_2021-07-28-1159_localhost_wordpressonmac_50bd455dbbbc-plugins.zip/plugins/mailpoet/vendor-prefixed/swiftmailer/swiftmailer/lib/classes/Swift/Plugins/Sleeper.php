<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; interface Swift_Plugins_Sleeper { public function sleep($seconds); } 