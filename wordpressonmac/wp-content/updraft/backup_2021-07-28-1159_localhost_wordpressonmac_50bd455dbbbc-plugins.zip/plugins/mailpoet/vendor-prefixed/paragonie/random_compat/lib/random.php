<?php
 namespace MailPoetVendor; if (!defined('ABSPATH')) exit; 