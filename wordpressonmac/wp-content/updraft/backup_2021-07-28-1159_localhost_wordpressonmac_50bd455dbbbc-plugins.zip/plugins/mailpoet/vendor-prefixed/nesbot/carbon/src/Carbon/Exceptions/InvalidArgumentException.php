<?php
 namespace MailPoetVendor\Carbon\Exceptions; if (!defined('ABSPATH')) exit; interface InvalidArgumentException extends \MailPoetVendor\Carbon\Exceptions\Exception { } 